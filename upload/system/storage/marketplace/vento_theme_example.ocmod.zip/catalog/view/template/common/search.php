<div id="search" class="input-group mb-3">
	<input type="text" name="search" value="<?= $this->e($search ) ?>" placeholder="<?= $this->e($text_search ) ?>" class="form-control form-control-lg">
	<button type="button" data-lang="<?= $this->e($language ) ?>" class="btn btn-secondary btn-lg"><i class="fa-solid fa-magnifying-glass"></i></button>
</div>
