 <?= isset($payment) ? $payment : '' ?> 
   
  