<div id="cookie">
    <div class="container">
        <div class="row mt-2">
            <div class="col-12 p-2 text-center">
                <p><?=  $text_cookie  ?></p>
                <button type="button" value="<?=  $agree  ?>" class="btn bg-primary btn-block text-white"><?= $this->e($button_agree) ?></button>&nbsp;&nbsp;&nbsp;<button type="button" value="<?= $this->e($disagree) ?>" class="btn btn-light btn-block"><?= $this->e($button_disagree) ?></button>
            </div>
        </div>
    </div>
</div>
