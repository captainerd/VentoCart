<?php $header ?>
<div id="content">
    <div class="container-fluid">
        <br/>
        <br/>
        <div class="row justify-content-sm-center">
            <div class="col-sm-10 col-md-8 col-lg-5">
                <div class="card">
                    <div class="card-header"><i class="fa-solid fa-lock"></i> <?= $this->e($heading_title) ?></div>
                    <div class="card-body">
                        <form id="form-authorize" action="<?=  $action ?>" method="post" data-oc-toggle="ajax">
                            <?php if ($error_warning): ?>
                                <div class="alert alert-danger alert-dismissible"><i class="fa-solid fa-circle-exclamation"></i> <?= $this->e($error_warning) ?> <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
                            <?php endif; ?>
                            <?php if ($success): ?>
                                <div class="alert alert-success alert-dismissible"><i class="fa-solid fa-check-circle"></i> <?= $this->e($success) ?> <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
                            <?php endif; ?>
                            <p><?= $this->e($text_security) ?></p>
                            <p><?= $this->e($text_code) ?></p>
                            <div class="mb-3">
                                <label for="input-code" class="form-label"><?= $this->e($entry_code) ?></label>
                                <div class="input-group">
                                    <input type="text" name="code" value="" placeholder="<?= $this->e($entry_code) ?>" id="input-code" class="form-control">
                                    <button type="button" id="button-send" class="btn btn-danger"><i class="fa-solid fa-mail-bulk"></i> <?= $this->e($button_resend) ?></button>
                                </div>
                                <div id="error-code" class="invalid-feedback"></div>
                            </div>
                            <div class="text-end">
                                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-key"></i> <?= $this->e($button_submit) ?></button>
                            </div>
                            <?php if ($redirect): ?>
                                <input type="hidden" name="redirect" value="<?= $redirect  ?>">
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script ><!--
$('#button-send').on('click', function (e) {
    e.preventDefault();

    $.ajax({
        url: 'index.php?route=common/authorize.send&user_token={{ user_token }}',
        dataType: 'json',
        beforeSend: function () {
            $('#button-send').button('loading');
        },
        complete: function () {
            $('#button-send').button('reset');
        },
        success: function (json) {
            //x console.log(json);

            if (json['redirect']) {
                location = json['redirect'];
            }

            if (json['error']) {
                $('#alert').prepend('<div class="alert alert-danger alert-dismissible"><i class="fa-solid fa-circle-exclamation"></i> ' + json['error'] + ' <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>');
            }

            if (json['success']) {
                $('#alert').prepend('<div class="alert alert-success alert-dismissible"><i class="fa-solid fa-check-circle"></i> ' + json['success'] + ' <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>');
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            //x console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
        }
    });
});

$('#button-send').trigger('click');
//--></script>
{{ footer }}

