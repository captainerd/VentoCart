<div>
    <?php if (!empty($heading_title)): ?>
        <h2><?=  $heading_title ?></h2>
    <?php endif; ?>
    <?= $html ?>
</div>
