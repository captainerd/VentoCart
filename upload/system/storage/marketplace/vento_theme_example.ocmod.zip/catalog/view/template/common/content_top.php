<?php foreach ($modules as $module): ?>
<?=  $module   ?>
<?php endforeach; ?>