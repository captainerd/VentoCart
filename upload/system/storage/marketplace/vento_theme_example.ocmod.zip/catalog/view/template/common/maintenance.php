<?=$header ?>
<div id="common-maintenance" class="container">
  <div class="row">
    <div class="col-12"><?=$message ?></div>
  </div>
</div>
<?=$footer ?>