<?php $header ?>
<div id="common-maintenance" class="container">
  <div class="row">
    <div class="col-12"><?php $message ?></div>
  </div>
</div>
<?php $footer ?>