<?=  $header  ?>
<div id="common-home" class="container">
  <div class="row"><?=  $column_left  ?>
    <div id="content" class="col"><?= $content_top   ?><?=  $content_bottom   ?></div>
    <?=  $column_right  ?></div>
</div>


 
<?= $footer  ?>