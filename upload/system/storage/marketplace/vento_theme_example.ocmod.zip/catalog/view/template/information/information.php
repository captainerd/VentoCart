<?=  $header    ?>
<div id="information-information" class="container">
  <?=  $breadcrumb   ?>
  <div class="row"><?=  $column_left  ?>
    <div id="content" class="col"><?=  $content_top  ?>
      <h1><?=  $heading_title  ?></h1>
      <?=  $description   ?><?=  $content_bottom  ?></div>
    <?=  $column_right  ?></div>
</div>
<?=  $footer  ?>