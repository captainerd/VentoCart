<?php $header ?>
<div id="content">
  <div class="container-fluid">
    <br/>
    <br/>
    <div class="row justify-content-sm-center">
      <div class="col-sm-10 col-md-8 col-lg-5">
        <div class="card">
          <div class="card-header"><i class="fa-solid fa-lock"></i> <?php $text_locked ?></div>
          <div class="card-body">
            <p>{<?php $text_unlock ?></p>
            <div class="d-grid">
              <button type="button" id="button-reset" class="btn btn-danger btn-lg"><i class="fa-solid fa-unlock"></i> <?php $button_reset ?></button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript"><!--
$('#button-reset').on('click', function (e) {
    e.preventDefault();

    $.ajax({
        url: 'index.php?route=common/authorize.confirm&user_token={{ user_token }}',
        dataType: 'json',
        beforeSend: function () {
            $('#button-reset').button('loading');
        },
        complete: function () {
            $('#button-reset').button('reset');
        },
        success: function (json) {
            //x console.log(json);

            if (json['redirect']) {
                location = json['redirect'];
            }

            if (json['error']) {
                $('#alert').prepend('<div class="alert alert-danger alert-dismissible"><i class="fa-solid fa-circle-exclamation"></i> ' + json['error'] + ' <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>');
            }

            if (json['success']) {
                $('#alert').prepend('<div class="alert alert-success alert-dismissible"><i class="fa-solid fa-check-circle"></i> ' + json['success'] + ' <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>');
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            //x console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
        }
    });
});
//--></script>
{{ footer }}

