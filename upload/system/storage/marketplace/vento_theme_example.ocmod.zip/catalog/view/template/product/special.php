<?=  $header    ?>
<div id="product-search" class="container">
<?=  $breadcrumb  ?>
  <div class="row"><?=  $column_left  ?>
    <div id="content" class="col"><?=  $content_top  ?>
      <h1><?= $this->e($heading_title ) ?></h1>
      <?php if ($products): ?>
        <div id="display-control" class="row">
          <div class="col-md-3">
            <div class="mb-3">
              <a href="<?= $compare  ?>" id="compare-total" class="btn btn-primary d-block"><i class="fa-solid fa-arrow-right-arrow-left"></i> <span class="d-inline d-md-none d-lg-inline"><?= $this->e($text_compare ) ?></span></a>
            </div>
          </div>
          <div class="col-md-1 d-none d-md-block">
            <div class="btn-group">
              <button type="button" id="button-list" class="btn btn-light" data-bs-toggle="tooltip" title="<?= $this->e($button_list ) ?>"><i class="fa-solid fa-table-list"></i></button>
              <button type="button" id="button-grid" class="btn btn-light" data-bs-toggle="tooltip" title="<?= $this->e($button_grid ) ?>"><i class="fa-solid fa-table-cells"></i></button>
            </div>
          </div>
          <div class="col-md-4 offset-md-1 col-6">
            <div class="input-group mb-3">
              <label for="input-sort" class="input-group-text"><?= $this->e($text_sort ) ?></label> <select id="input-sort" class="form-select" onchange="location = this.value;">
                <?php foreach ($sorts as $sorts): ?>
                  <option value="<?= $sorts['href'] ?>"<?php if ($sorts->value == sprintf('%s-%s', $sort, $order)): ?> selected<?php endif; ?>><?= $this->e($sorts['text']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="col-md-3 col-6">
            <div class="input-group mb-3">
              <label for="input-limit" class="input-group-text"><?= $this->e($text_limit ) ?></label>
              <select id="input-limit" class="form-select" onchange="location = this.value;">
                <?php foreach ($limits as $limits): ?>
                  <option value="<?= $limits['href'] ?>"<?php if ($limits['value'] == $$limit): ?> selected<?php endif; ?>><?= $this->e($limits['text']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
        </div>
        <div id="product-list" class="row row-cols-1 row-cols-sm-2 row-cols-md-2 row-cols-lg-4">
          <?php foreach ($products as $product): ?>
            <div class="col mb-3"><?=  $product  ?></div>
          <?php endforeach; ?>
        </div>
        <div class="row">
          <div class="col-sm-6 text-start"><?= $pagination   ?></div>
          <div class="col-sm-6 text-end"><?=  $results  ?></div>
        </div>
      <?php else: ?>
        <p><?=  $text_no_results  ?></p>
        <div class="text-end"><a href="<?= $continue  ?>" class="btn btn-primary"><?= $this->e($button_continue ) ?></a></div>
      <?php endif; ?>
      <?=  $content_bottom  ?></div>
    <?=  $column_right  ?></div>
</div>
<?=  $footer  ?>
