<?php
namespace Opencart\Catalog\Controller\Extension\Ventothemeexample\Startup;

class Ventothemeexample extends \Opencart\System\Engine\Controller
{
	public function index(): void
	{

		if ($this->config->get('config_theme') == 'vento_theme_example' && $this->config->get('theme_vento_theme_example_status')) {

			// Add event via code instead of DB
			// Could also just set view/common/header/before
			$this->event->register('view/*/before', new \Opencart\System\Engine\Action('extension/vento_theme_example/startup/vento_theme_example.event'));
		}
	}

	public function event(string &$route, array &$args, mixed &$output): void
	{

 
		// This is the default theme copied as it is with a little CSS editing
		// Edit the theme files you want, 
		// when you finish feel free to delete files and remove overrides of files you haven't edited.

		$override = [

			//Common

			'common/header',
			'common/cart',
			'common/breadcrumb',
			'common/content_top',
			'common/home',
			'common/search',
			'common/cart',
			'common/cookie',
			'common/language',
			'common/success',
			'common/column_left',
			'common/currency',
			'common/maintenance',
			'common/column_right',
			'common/footer',
			'common/menu',
			'common/content_bottom',
			'common/header',
			'common/pagination',


			//Account
			'account/account',
			'account/login',
			'account/returns_list',
			'account/address_form',
			'account/newsletter',
			'account/reward',
			'account/address_list',
			'account/order_history',
			'account/subscription_history',
			'account/address',
			'account/order_info',
			'account/subscription_info',
			'account/affiliate',
			'account/order_list',
			'account/subscription_list',
			'account/authorize',
			'account/password',
			'account/authorize_unlock',
			'account/payment_method_list',
			'account/tracking',
			'account/download',
			'account/payment_method',
			'account/transaction',
			'account/edit',
			'account/register',
			'account/forgotten',
			'account/returns_form',
			'account/wishlist_list',
			'account/forgotten_reset',
			'account/returns_info',
			'account/wishlist',
			'account/subscription_order',

			//CheckOut
			'checkout/address',
			'checkout/checkout_ajax',
			'checkout/register',
			'checkout/cart_list',
			'checkout/confirm',
			'checkout/shipping_payment_methods',
			'checkout/cart',
			'checkout/payment',
			'checkout/voucher',

			//CMS
			'cms/blog_info',
			'cms/blog_list',
			'cms/comment_list',
			'cms/comment',

			//Error
			'error/not_found',

			//Information
			'information/contact',
			'information/gdpr',
			'information/information_info',
			'information/information',
			'information/sitemap',

			//Product 
			'product/category',
			'product/manufacturer_info',
			'product/product',
			'product/review',
			'product/special',
			'product/compare',
			'product/manufacturer_list',
			'product/review_list',
			'product/search',
			'product/thumb',

			//Modules by OpenCart
			'extension/opencart/module/account',
			'extension/opencart/module/category',
			'extension/opencart/module/html',
			'extension/opencart/module/special',
			'extension/opencart/module/banner',
			'extension/opencart/module/featured',
			'extension/opencart/module/information',
			'extension/opencart/module/store',
			'extension/opencart/module/bestseller',
			'extension/opencart/module/filter',
			'extension/opencart/module/latest',

			//Modules by VentoCart
			'extension/ventocart/module/information',
			'extension/ventocart/module/attribute_filter',
			'extension/ventocart/module/mostviewed',
			'extension/ventocart/module/topic_preview',
			'extension/ventocart/module/availability_filter',
			'extension/ventocart/module/option_filter',
			'extension/ventocart/module/manufacturer_filter',
			'extension/ventocart/module/topic',
		];

 
		// This changes only the header.php stylesheet link
		 if ($route === 'common/header') {
			$args['stylesheet'] = "extension/vento_theme_example/catalog/view/stylesheet/stylesheet.css";
			$args['cssframework'] = "extension/vento_theme_example/catalog/view/stylesheet/bootstrap.css";
		 }
		 if ($route === 'common/footer') {
			$args['cssframework'] = "extension/vento_theme_example/catalog/view/javascript/bootstrap/js/bootstrap.bundle.min.js";
		 }

		if (in_array($route, $override)) {
			 	 
			$route = 'extension/vento_theme_example/' . $route;
		}
	}
}