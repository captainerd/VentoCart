<?php
$_['heading_title'] = 'Pickup From Store';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified pickup from store!';
$_['text_edit'] = 'Edit Pickup From Store Shipping';
$_['entry_geo_zone'] = 'Geo Zone';
$_['entry_status'] = 'Status';
$_['entry_sort_order'] = 'Sort Order';
$_['error_permission'] = 'Warning: You do not have permission to modify pickup from store!';

?>