<?php
$_['heading_title'] = 'Reward Points';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified reward points total!';
$_['text_edit'] = 'Edit Reward Points Total';
$_['entry_status'] = 'Status';
$_['entry_sort_order'] = 'Sort Order';
$_['error_permission'] = 'Warning: You do not have permission to modify reward points total!';

?>