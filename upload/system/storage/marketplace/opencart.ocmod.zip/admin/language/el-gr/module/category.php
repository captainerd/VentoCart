<?php
$_['heading_title'] = 'Category';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified category module!';
$_['text_edit'] = 'Edit Category Module';
$_['entry_status'] = 'Status';
$_['error_permission'] = 'Warning: You do not have permission to modify category module!';

?>