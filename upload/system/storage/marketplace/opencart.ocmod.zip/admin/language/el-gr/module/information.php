<?php
$_['heading_title'] = 'Information';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified information module!';
$_['text_edit'] = 'Edit Information Module';
$_['entry_status'] = 'Status';
$_['error_permission'] = 'Warning: You do not have permission to modify information module!';

?>