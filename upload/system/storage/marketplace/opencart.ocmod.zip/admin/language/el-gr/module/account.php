<?php
$_['heading_title'] = 'Account';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified account module!';
$_['text_edit'] = 'Edit Account Module';
$_['entry_status'] = 'Status';
$_['error_permission'] = 'Warning: You do not have permission to modify account module!';

?>