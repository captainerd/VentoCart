<?php
$_['heading_title'] = 'Total';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified total totals!';
$_['text_edit'] = 'Edit Total Total';
$_['entry_status'] = 'Status';
$_['entry_sort_order'] = 'Sort Order';
$_['error_permission'] = 'Warning: You do not have permission to modify total totals!';

?>