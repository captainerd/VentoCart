<?php
$_['heading_title'] = 'Taxes';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified taxes total!';
$_['text_edit'] = 'Edit Tax Total';
$_['entry_status'] = 'Status';
$_['entry_sort_order'] = 'Sort Order';
$_['error_permission'] = 'Warning: You do not have permission to modify taxes total!';

?>