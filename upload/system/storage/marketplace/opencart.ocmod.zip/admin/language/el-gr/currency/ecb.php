<?php
$_['heading_title'] = 'European Central Bank Currency Converter';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified European Central Bank Currency Converter!';
$_['text_edit'] = 'Edit European Central Bank';
$_['text_support'] = 'This extension requires the EUR currency.';
$_['entry_status'] = 'Status';
$_['error_permission'] = 'Warning: You do not have permission to modify European Central Bank Currency Converter!';

?>