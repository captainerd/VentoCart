<?php
$_['heading_title'] = 'Cash On Delivery';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified cash on delivery payment module!';
$_['text_edit'] = 'Edit Cash On Delivery';
$_['entry_order_status'] = 'Order Status';
$_['entry_geo_zone'] = 'Geo Zone';
$_['entry_status'] = 'Status';
$_['entry_sort_order'] = 'Sort Order';
$_['error_permission'] = 'Warning: You do not have permission to modify payment cash on delivery!';

?>