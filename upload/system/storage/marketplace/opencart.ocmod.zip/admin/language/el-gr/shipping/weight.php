<?php
$_['heading_title'] = 'Weight Based Shipping';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified weight based shipping!';
$_['text_edit'] = 'Edit Weight Based Shipping';
$_['entry_rate'] = 'Rates';
$_['entry_tax_class'] = 'Tax Class';
$_['entry_geo_zone'] = 'Geo Zone';
$_['entry_status'] = 'Status';
$_['entry_sort_order'] = 'Sort Order';
$_['help_rate'] = 'Example: 5:10.00,7:12.00 Weight:Cost,Weight:Cost, etc..';
$_['error_permission'] = 'Warning: You do not have permission to modify weight based shipping!';

?>