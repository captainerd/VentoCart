<?php
// Heading
$_['heading_title']    = 'Topic';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified topic module!';
$_['text_edit']        = 'Edit Topic Module';
$_['entry_preview_word_count'] = 'Preview word count';
$_['entry_name'] = 'Name';
// Entry
$_['entry_status']     = 'Status';
$_['entry_preview'] = "Preview description";

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify topic module!';