<?php
$_['heading_title'] = 'Information';
$_['text_contact'] = 'Contact Us';
$_['text_sitemap'] = 'Site Map';

?>