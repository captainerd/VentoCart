<?php
$_['heading_title'] = 'Choose a Store';
$_['text_default'] = 'Default';
$_['text_store'] = 'Please choose the store you wish to visit.';

?>