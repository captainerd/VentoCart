<?php
$_['heading_title'] = 'Free Shipping';
$_['text_description'] = 'Free Shipping';

?>