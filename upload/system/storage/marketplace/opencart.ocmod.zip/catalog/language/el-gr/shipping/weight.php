<?php
$_['heading_title'] = 'Weight Based Shipping';
$_['text_weight'] = 'Weight:';

?>