<?php
$_['heading_title'] = 'Latest';

?>