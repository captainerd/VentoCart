<?php
$_['heading_title'] = 'Best Sellers';

?>