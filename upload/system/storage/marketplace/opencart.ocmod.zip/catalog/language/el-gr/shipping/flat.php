<?php
$_['heading_title'] = 'Flat Rate';
$_['text_description'] = 'Flat Shipping Rate';

?>