<?php
$_['heading_title'] = 'Most Popular';

?>