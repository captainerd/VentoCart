<?php
$_['text_captcha'] = 'Captcha';
$_['entry_captcha'] = 'Enter the code in the box below';
$_['error_captcha'] = 'Verification code does not match the image!';

?>