<?php
$_['heading_title'] = 'Cash On Delivery';
$_['error_order_id'] = 'No order ID in the session!';
$_['error_payment_method'] = 'Payment method is incorrect!';

?>