<?php
$_['heading_title'] = 'Categories';

?>