<?php
$_['heading_title'] = 'Specials';

?>