<?php
$_['heading_title'] = 'Pickup';
$_['text_description'] = 'Pickup From Store';

?>