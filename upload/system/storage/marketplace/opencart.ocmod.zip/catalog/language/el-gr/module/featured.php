<?php
$_['heading_title'] = 'Featured';

?>