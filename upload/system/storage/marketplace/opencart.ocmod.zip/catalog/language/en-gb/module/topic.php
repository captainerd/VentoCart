<?php
// Heading
$_['heading_title'] = 'Topics';
$_['text_all']        = 'All Topics';