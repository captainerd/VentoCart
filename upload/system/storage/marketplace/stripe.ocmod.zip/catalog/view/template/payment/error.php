<div class="p-3 m-3 alert-danger" role="alert">
  <i class="fas fa-exclamation-circle"></i> <?=$error_subscription?>
</div>
