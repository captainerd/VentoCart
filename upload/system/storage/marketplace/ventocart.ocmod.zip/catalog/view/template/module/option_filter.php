<?php foreach ($filter_options as $optionSet): ?>
  <div class="card  mb-3">
    <form method="get" action=" " class="option_form">
      <?php foreach ($optionSet as $option): ?>
        <?php if ($option['option_n'] == -1): ?>
          <div class="card-header">
            <i class="fa-solid fa-filter"></i>
            <strong>
              <?= $option['name'] ?>
            </strong>
          </div>
      <?php else: ?>
          <div class="list-group list-group-flush">

            <div class="list-group-item">
              <div id="filter-option-group-<?= $option['option_id'] ?>">
                <div class="form-check">
                  <input type="checkbox" name="filter_option[]" value="<?= $option['option_id'] ?>" id="input-option-filter-<?= $option['option_id'] ?>" class="form-check-input option-checkbox" <?= (in_array($option['option_id'], $selected_options)) ? 'checked' : '' ?>/>
                  <label for="input-option-filter-<?= $option['option_id'] ?>" class="form-check-label">
                  <?php if (isset($option['image']) && $option['image'] != ""):?>
                    <img src="/index.php?route=product/product.getImage&image=<?= $option['image']; ?>&width=25&height=25" alt="Option Image" class="img-fluid rounded-circle" style="width: 25px; height: 25px;">

                    <?php endif;?>

                  <?= $option['name'] ?></label>
                </div>
              </div>
            </div>
          </div>
        <?php endif; ?>
      <?php endforeach; ?>
 
 

    </form>
  </div>
<?php endforeach; ?>

<script>
$(document).ready(function() {
    // Catch the form submission
    $(".option-checkbox").on('change',  function(event) {
        // Prevent the default form submission
        event.preventDefault();

        // Get the serialized form data
        let formData = $(".option_form").serialize();
  
        // Get the existing URL parameters
        let existingGet = window.location.search.substring(1); // Exclude the leading '?'
        
        // Parse the existing parameters
        let existingParams = new URLSearchParams(existingGet);
        existingParams.delete('filter_option[]');
        // Parse the form data
        let formParams = new URLSearchParams(formData);
 

        // Combine existing and form parameters
        let combinedParams = new URLSearchParams(existingParams.toString() + '&' + formParams.toString());
   
        // Set the new URL with the updated parameters
         window.location.href = window.location.pathname + '?' + decodeURIComponent(combinedParams.toString());
    });
});
</script>