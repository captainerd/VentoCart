<?php

$_['heading_title'] = 'Zone Shipping';
$_['text_description'] = 'Zone Shipping';
