<?php

$_['heading_title'] = 'Manufacturers';