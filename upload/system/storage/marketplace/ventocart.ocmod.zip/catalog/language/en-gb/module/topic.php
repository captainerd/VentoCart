<?php
// Heading
$_['heading_title'] = 'Topics';
$_['text_all']        = 'All Topics';
$_['text_readmore'] = "Read more";