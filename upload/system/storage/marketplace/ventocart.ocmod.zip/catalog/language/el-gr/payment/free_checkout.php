<?php
// Heading
$_['heading_title'] = 'Free Checkout';