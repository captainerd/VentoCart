<?php
namespace Opencart\Catalog\Controller\Extension\VentoCart\Captcha;

/**
 * Class Basic
 *
 * @package Opencart\Catalog\Controller\Extension\VentoCart\Captcha
 */
class Basic extends \Opencart\System\Engine\Controller
{
	/**
	 * @return string
	 */
	public function index(): string
	{
		$this->load->language('extension/ventocart/captcha/basic');

		$data['route'] = (string) $this->request->get['route'];

		$this->session->data['captcha'] = substr(oc_token(100), rand(0, 94), 6);

		return $this->load->view('extension/ventocart/captcha/basic', $data);
	}

	/**
	 * @return string
	 */
	public function validate(): string
	{
		$this->load->language('extension/ventocart/captcha/basic');

		if (!isset($this->session->data['captcha']) || !isset($this->request->post['captcha']) || ($this->session->data['captcha'] != $this->request->post['captcha'])) {
			return $this->language->get('error_captcha');
		} else {
			return '';
		}
	}

	/**
	 * @return void
	 */
	public function captcha(): void
	{
		$captchaText = $this->session->data['captcha'];

		$image = imagecreatetruecolor(150, 35);

		$width = imagesx($image);
		$height = imagesy($image);

		$black = imagecolorallocate($image, 0, 0, 0);
		$white = imagecolorallocate($image, 255, 255, 255);

		imagefilledrectangle($image, 0, 0, $width, $height, $white);

		imagefilledrectangle($image, 0, 0, $width, 0, $black);
		imagefilledrectangle($image, $width - 1, 0, $width - 1, $height - 1, $black);
		imagefilledrectangle($image, 0, 0, 0, $height - 1, $black);
		imagefilledrectangle($image, 0, $height - 1, $width, $height - 1, $black);


		$captchaText = $this->session->data['captcha'];



		imagestring($image, 10, intval(($width - (strlen($captchaText) * 9)) / 2), intval(($height - 15) / 2), $captchaText, $black);

		for ($y = 0; $y < $height; $y++) {
			for ($x = 0; $x < $width; $x++) {
				if (mt_rand(0, 12) == 2) {
					imagesetpixel($image, $x, $y, $black);
				}
			}
		}

 

		header('Content-type: image/jpeg');
		header('Cache-Control: no-cache');
		header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');

		imagejpeg($image);

		imagedestroy($image);
		exit();
	}
}
