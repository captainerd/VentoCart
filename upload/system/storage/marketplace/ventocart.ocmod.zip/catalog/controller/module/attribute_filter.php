<?php
namespace Opencart\Catalog\Controller\Extension\Ventocart\Module;
/**
 * Class Filter
 *
 * @package Opencart\Catalog\Controller\Extension\VentoCart\Module
 */
class AttributeFilter extends \Opencart\System\Engine\Controller {
	/**
	 * @return string
	 */
	public function index(): string {

	 
	 
		if (isset($this->request->get['path'])) {
			$parts = explode('_', (string)$this->request->get['path']);
		} else {
			$this->request->get['path'] = '';
			$parts = [];
		}

		$category_id = end($parts);

		$this->load->model('catalog/category');

		$category_info = $this->model_catalog_category->getCategory($category_id);

		if ($category_info) {
			$this->load->language('extension/ventocart/module/option_filter');

			 
			$data['filter_option'] = isset($this->request->get['filter_option']) ? $this->request->get['filter_option'] : [];
			$data['filter_availabilities'] = isset($this->request->get['filter_availabilities']) ? $this->request->get['filter_availabilities'] : [];
			if (isset($this->request->get['filter'])) {
				$data['filter_category'] = explode(',', $this->request->get['filter']);
			} else {
				$data['filter_category'] = [];
			}
			$data['selected_attributes'] = [];
			if (isset($this->request->get['filter_attribute'])) {
				$data['selected_attributes'] = $this->request->get['filter_attribute'];
			}
			$this->load->model('catalog/product');

	 

			$data['filter_attributes'] = $this->model_catalog_category->getAttributeFilters($category_id);

	 

				return $this->load->view('extension/ventocart/module/attribute_filter', $data);
		 
		}

		return '';
	}
}
