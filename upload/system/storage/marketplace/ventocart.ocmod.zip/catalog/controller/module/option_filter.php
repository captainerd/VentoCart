<?php
namespace Opencart\Catalog\Controller\Extension\VentoCart\Module;
/**
 * Class Filter
 *
 * @package Opencart\Catalog\Controller\Extension\VentoCart\Module
 */
class Optionfilter extends \Opencart\System\Engine\Controller {
	/**
	 * @return string
	 */
	public function index(): string {

	 
	 
		if (isset($this->request->get['path'])) {
			$parts = explode('_', (string)$this->request->get['path']);
		} else {
			$this->request->get['path'] = '';
			$parts = [];
		}

		$category_id = end($parts);

		$this->load->model('catalog/category');

		$category_info = $this->model_catalog_category->getCategory($category_id);

		if ($category_info) {
			$this->load->language('extension/ventocart/module/option_filter');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}

			$data['action'] = str_replace('&amp;', '&', $this->url->link('product/category', 'language=' . $this->config->get('config_language') . '&path=' . $this->request->get['path'] . $url));
			$data['language'] = $this->config->get('config_language');
			$data['path'] = $this->request->get['path'];
			$data['route'] = 'product/category';
 
			$data['filter_attribute'] = isset($this->request->get['filter_attribute']) ? $this->request->get['filter_attribute'] : [];
			$data['filter_availabilities'] = isset($this->request->get['filter_availabilities']) ? $this->request->get['filter_availabilities'] : [];
			if (isset($this->request->get['filter'])) {
				$data['filter_category'] = explode(',', $this->request->get['filter']);
			} else {
				$data['filter_category'] = [];
			}

			$data['selected_options'] = [];
			if (isset($this->request->get['filter_option'])) {
				$data['selected_options'] = $this->request->get['filter_option'];
			}

 


			$this->load->model('catalog/product');

	 

			$data['filter_options'] = $this->model_catalog_category->getOptionFilters($category_id);
 
 

				return $this->load->view('extension/ventocart/module/option_filter', $data);
		 
		}

		return '';
	}
}
