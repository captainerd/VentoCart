<?php
// Heading
$_['heading_title']    = 'Option Filter';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Option filter module!';
$_['text_edit']        = 'Edit Option Filter Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify option filter module!';