<?php

$_['heading_title']    = 'Google Analytics Tag';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Google Analytics Tag!';
$_['text_edit']        = 'Edit Google Analytics Tag';
$_['select_store']     = 'Select store';
// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Google Analytics Tag!';

?>