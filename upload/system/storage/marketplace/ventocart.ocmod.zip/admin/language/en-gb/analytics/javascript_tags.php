<?php

$_['heading_title']    = 'JavaScript Tags';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified JavaScript Tags!';
$_['text_edit']        = 'Edit JavaScript Tags';
$_['select_store']     = 'Select store';
// Entry
$_['entry_status']     = 'Status';
$_['entry_javascript_tags'] = 'JavaScript Tags';
$_['entry_javascript_tags_placeholder'] = 'Enter Tags, eg Facebook Pixel etc';
// Error
$_['error_permission'] = 'Warning: You do not have permission to modify JavaScript Tags!';

?>