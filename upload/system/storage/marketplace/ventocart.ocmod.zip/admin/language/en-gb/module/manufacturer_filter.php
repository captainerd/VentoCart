<?php
// Heading
$_['heading_title']    = 'Manufacturer Filter';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified manufacturer filter module!';
$_['text_edit']        = 'Edit Manufacturer Filter Module';

// Entry
$_['entry_status']     = 'Status';
$_['entry_show_icon']  = 'Show Icon';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify manufacturer filter module!';