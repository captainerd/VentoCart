<?php
// Heading
$_['heading_title']    = 'Availability filter';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Availability filter module!';
$_['text_edit']        = 'Edit Availability Filter Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify availability filter module!';